# quotes

I'm launching 🚀 my new ✨ SaaS providing quotes 📝 as an API 💪!

## Run

```
docker build . -t quotes
docker run -p 3000:3000 quotes
```

Then go to https://localhost:3000
