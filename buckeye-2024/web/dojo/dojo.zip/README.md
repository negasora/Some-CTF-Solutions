# dojo

The dojo stores many riches. Can you make it through the gauntlet?

## Run

```
docker build . -t dojo
docker run -p 8080:8080 dojo
```

Then go to https://localhost:8080
